document.getElementById('themeButton').addEventListener('click', ()=>document.body.classList.toggle('light'));
console.log('FanCardShop initialized');